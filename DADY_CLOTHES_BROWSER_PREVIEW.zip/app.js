
const products = [
  {id:1,name:"Oversized Black T-Shirt",category:"T-Shirts",price:699,oldPrice:999,stock:12,emoji:"👕"},
  {id:2,name:"Premium Pink Hoodie",category:"Hoodies",price:899,oldPrice:1299,stock:8,emoji:"🧥"},
  {id:3,name:"Classic Black Shirt",category:"Shirts",price:799,oldPrice:1099,stock:15,emoji:"👔"},
  {id:4,name:"Streetwear Cargo",category:"Pants",price:999,oldPrice:1399,stock:10,emoji:"👖"},
  {id:5,name:"DADY Signature Tee",category:"T-Shirts",price:599,oldPrice:799,stock:20,emoji:"👕"},
  {id:6,name:"Black Essential Hoodie",category:"Hoodies",price:1099,oldPrice:1499,stock:7,emoji:"🧥"}
];

let cart = JSON.parse(localStorage.getItem("dady_cart") || "[]");

function money(n){return "₹"+n.toLocaleString("en-IN")}
function save(){localStorage.setItem("dady_cart",JSON.stringify(cart)); renderCartCount()}
function renderCartCount(){
  const n=cart.reduce((s,x)=>s+x.qty,0);
  document.querySelectorAll("#cartCount,.cart-count").forEach(e=>e.textContent=n);
}
function productCard(p){
 return `<article class="product-card">
   <div class="product-img"><span>${p.emoji}</span><small>${p.category}</small></div>
   <div class="product-info"><h3>${p.name}</h3>
   <div class="price">${money(p.price)} <del>${money(p.oldPrice)}</del></div>
   <button class="add-btn" onclick="addToCart(${p.id})">Add to Cart</button></div>
 </article>`;
}
function renderProducts(list=products){
 const grids=document.querySelectorAll("#productGrid,.product-grid");
 grids.forEach(g=>g.innerHTML=list.map(productCard).join(""));
}
function addToCart(id){
 const p=products.find(x=>x.id===id); if(!p)return;
 const item=cart.find(x=>x.id===id);
 if(item)item.qty++; else cart.push({...p,qty:1});
 save(); alert(p.name+" cart me add ho gaya! 🛍️");
}
function removeFromCart(id){cart=cart.filter(x=>x.id!==id);save();renderCart()}
function changeQty(id,d){
 const x=cart.find(i=>i.id===id); if(!x)return;
 x.qty+=d;if(x.qty<=0)removeFromCart(id);else{save();renderCart()}
}
function renderCart(){
 const box=document.querySelector("#cartItems"); if(!box)return;
 if(!cart.length){box.innerHTML="<p>Your cart is empty.</p>";return}
 box.innerHTML=cart.map(x=>`<div class="cart-item">
 <b>${x.name}</b><span>${money(x.price)} × ${x.qty}</span>
 <button onclick="changeQty(${x.id},-1)">−</button><button onclick="changeQty(${x.id},1)">+</button>
 <button onclick="removeFromCart(${x.id})">Remove</button></div>`).join("");
 const total=cart.reduce((s,x)=>s+x.price*x.qty,0);
 const t=document.querySelector("#cartTotal");if(t)t.textContent=money(total);
}
window.addToCart=addToCart;window.removeFromCart=removeFromCart;window.changeQty=changeQty;

document.addEventListener("DOMContentLoaded",()=>{
 renderProducts();renderCart();renderCartCount();
 document.querySelectorAll("[data-category]").forEach(b=>b.addEventListener("click",()=>{
   const c=b.dataset.category;renderProducts(c==="All"?products:products.filter(p=>p.category===c));
 }));
 const form=document.querySelector("#checkoutForm");
 if(form)form.addEventListener("submit",e=>{
   e.preventDefault();
   if(!cart.length){alert("Cart empty hai.");return}
   const id="DADY"+Math.floor(100000+Math.random()*900000);
   cart=[];save();renderCart();
   alert("Order placed! 🎉 Order ID: "+id+"\\nPayment: Cash on Delivery");
 });
});
